using System;

namespace TicketingSystem.Api.DTOs.Auth;

public class GoogleLoginDto
{
     public string IdToken { get; set; } = string.Empty;
}
